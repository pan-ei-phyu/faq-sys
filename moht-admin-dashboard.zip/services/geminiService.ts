import { GoogleGenAI, Type } from "@google/genai";
import type { FaqItem } from '../types';

const generateInitialFaqs = async (): Promise<FaqItem[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: "Create 5 frequently asked questions (FAQs) in Burmese. Provide the response in JSON format. Each FAQ must have a 'title' (string) and an 'answer' (string).",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              answer: { type: Type.STRING },
            },
            required: ["title", "answer"],
          },
        },
      },
    });

    const jsonResponse = JSON.parse(response.text);
    return jsonResponse.map((faq: any, index: number) => ({
      id: `gemini-${Date.now()}-${index}`,
      ...faq,
    }));
  } catch (error) {
    console.error("Gemini API ခေါ်ယူရာတွင် အမှားအယွင်းဖြစ်ပွားသည်:", error);
    // Fallback to static data if API fails
    return [
        { id: 'static-1', title: 'အကောင့်ဘယ်လိုဖွင့်ရမလဲ။', answer: 'အကောင့်ဖွင့်ရန် "Register" ခလုတ်ကိုနှိပ်ပြီး လိုအပ်သောအချက်အလက်များကို ဖြည့်သွင်းပါ။' },
        { id: 'static-2', title: 'စကားဝှက်မေ့သွားရင် ဘယ်လိုလုပ်ရမလဲ။', answer: 'Login စာမျက်နှာရှိ "Forgot Password" ကိုနှိပ်ပြီး အီးမေးလ်လိပ်စာထည့်သွင်းကာ ညွှန်ကြားချက်များအတိုင်း လိုက်နာဆောင်ရွက်ပါ။' },
        { id: 'static-3', title: 'ဝန်ဆောင်မှုကို ဘယ်လိုဆက်သွယ်ရမလဲ။', answer: 'ကျွန်ုပ်တို့၏ "Contact Us" စာမျက်နှာမှတဆင့် ဆက်သွယ်နိုင်ပါသည်။' },
        { id: 'static-4', title: 'App ကို Mobile တွင်အသုံးပြုနိုင်ပါသလား။', answer: 'ဟုတ်ကဲ့၊ ကျွန်ုပ်တို့၏ ဝဘ်ဆိုဒ်သည် မိုဘိုင်းလ်ဖုန်းများအတွက် အထူးသင့်လျော်အောင် ပြုလုပ်ထားပါသည်။' },
    ];
  }
};

export { generateInitialFaqs };
