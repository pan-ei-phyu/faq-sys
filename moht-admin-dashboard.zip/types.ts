export interface FaqItem {
  id: string;
  title: string;
  answer: string;
}
