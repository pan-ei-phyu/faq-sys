import React, { useState, useEffect } from 'react';
import { MenuIcon, BellIcon, EnvelopeIcon, LogoutIcon, LogoIcon, ChevronDownIcon } from './icons';
import AdminPage from './AdminPage';
import FaqPage from './FaqPage';
import { generateInitialFaqs } from '../services/geminiService';
import type { FaqItem } from '../types';


// --- Reusable Components defined inside Dashboard file ---
const StatCard = ({ title, value, total }: { title: string, value: string, total: string }) => (
  <div className="bg-white p-6 rounded-lg shadow-md flex-1">
    <div className="flex justify-between items-start">
      <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
      <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded-full">{total}</span>
    </div>
    <p className="text-4xl font-bold text-gray-800 mt-2">{value}</p>
  </div>
);

// --- Layout Components ---

const Sidebar = ({ currentPage, setCurrentPage }: { currentPage: string, setCurrentPage: (page: string) => void }) => {
    const navItems = [
        { name: 'Dashboard', page: 'Dashboard' },
        { name: 'All Admins', page: 'Admins' },
        { name: 'FAQ', page: 'FAQ' }
    ];

    return (
        <aside className="w-64 bg-slate-800 text-slate-300 flex-shrink-0 flex flex-col">
            <div className="h-16 flex items-center justify-center px-4 border-b border-slate-700">
                <h1 className="text-white text-lg font-semibold ml-3">Ministry Of Hotels & Tourism</h1>
            </div>
            <nav className="flex-1 px-4 py-4 space-y-2">
                {navItems.map(item => (
                     <a
                        key={item.name}
                        href="#"
                        onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(item.page);
                        }}
                        className={`flex items-center justify-between px-4 py-2 rounded-md transition-colors ${currentPage === item.page ? 'text-white bg-slate-700' : 'hover:bg-slate-700'}`}
                     >
                        <span>{item.name}</span>
                    </a>
                ))}
            </nav>
        </aside>
    );
};

const Header = ({ onLogout, currentPage }: { onLogout: () => void, currentPage: string }) => (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
        <div className="flex items-center">
            <button className="text-gray-500 mr-4 md:hidden">
                <MenuIcon className="h-6 w-6"/>
            </button>
            <div className="text-sm text-gray-500">
                Home / <span className="text-gray-700 font-medium">{currentPage}</span>
            </div>
        </div>
        <div className="flex items-center space-x-4">
            <button className="text-gray-500 hover:text-gray-700">
                <EnvelopeIcon className="h-6 w-6"/>
            </button>
            <button className="text-gray-500 hover:text-gray-700">
                <BellIcon className="h-6 w-6"/>
            </button>
            <button onClick={onLogout} className="flex items-center text-gray-500 hover:text-gray-700">
                <LogoutIcon className="h-6 w-6 mr-2"/>
                <span className="text-sm font-medium">Log out</span>
            </button>
        </div>
    </header>
);

const DashboardHome = ({ faqCount }: { faqCount: number }) => {
    return (
        <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <StatCard title="Total FAQs" value={faqCount.toString()} total="Total" />
            </div>
        </>
    );
};

// --- Main Dashboard Component ---

const Dashboard = ({ onLogout }: { onLogout: () => void }) => {
    const [currentPage, setCurrentPage] = useState('Dashboard');
    const [faqs, setFaqs] = useState<FaqItem[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchFaqs = async () => {
            setIsLoading(true);
            try {
                const initialFaqs = await generateInitialFaqs();
                setFaqs(initialFaqs);
            } catch (e) {
                setError('FAQ ဒေတာများရယူရာတွင် အမှားအယွင်းဖြစ်ပွားနေပါသည်။');
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        };
        fetchFaqs();
    }, []);

    const handleSaveFaq = (faqData: Omit<FaqItem, 'id'>, id?: string) => {
        if (id) {
            setFaqs(faqs.map(f => f.id === id ? { ...f, ...faqData } : f));
        } else {
            const newFaq = { id: `user-${Date.now()}`, ...faqData };
            setFaqs([newFaq, ...faqs]);
        }
    };

    const handleDeleteFaq = (faqToDelete: FaqItem) => {
        if(faqToDelete) {
            setFaqs(faqs.filter(f => f.id !== faqToDelete.id));
        }
    };

    const renderContent = () => {
        switch (currentPage) {
            case 'Dashboard':
                return <DashboardHome faqCount={faqs.length} />;
            case 'Admins':
                return <AdminPage />;
            case 'FAQ':
                return <FaqPage 
                            faqs={faqs} 
                            isLoading={isLoading} 
                            error={error}
                            onSave={handleSaveFaq}
                            onDelete={handleDeleteFaq}
                        />;
            default:
                return (
                    <div className="bg-white p-6 rounded-lg shadow-lg">
                        <h1 className="text-2xl font-bold text-gray-800">{currentPage}</h1>
                        <p className="mt-4 text-gray-600">This page is under construction.</p>
                    </div>
                );
        }
    };

    return (
        <div className="flex h-screen bg-gray-100 font-sans">
            <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header onLogout={onLogout} currentPage={currentPage} />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
                    <div className="p-6">
                        {renderContent()}
                    </div>
                    <footer className="text-center py-4 text-sm text-gray-500 bg-gray-200">
                        Copyright Ministry of Hotels & Tourism © 2025.
                        <span className="ml-4">Developed By MISL</span>
                    </footer>
                </main>
            </div>
        </div>
    );
};

export default Dashboard;