import React from 'react';

const AdminPage = () => {
    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Admin Management</h1>
            <div className="bg-white p-8 rounded-lg shadow-lg">
                <p className="text-gray-700">
                    This is where you would manage site administrators. 
                    Functionality to add, edit, and remove admins can be implemented here.
                </p>
            </div>
        </div>
    );
};

export default AdminPage;