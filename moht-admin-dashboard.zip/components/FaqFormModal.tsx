import React, { useState, useEffect } from 'react';
import type { FaqItem } from '../types';
import { CloseIcon } from './icons';

interface FaqFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (faq: Omit<FaqItem, 'id'>, id?: string) => void;
  faq: FaqItem | null;
}

const FaqFormModal: React.FC<FaqFormModalProps> = ({ isOpen, onClose, onSave, faq }) => {
  const [title, setTitle] = useState('');
  const [answer, setAnswer] = useState('');

  useEffect(() => {
    if (isOpen) {
      setTitle(faq?.title || '');
      setAnswer(faq?.answer || '');
    }
  }, [isOpen, faq]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim() && answer.trim()) {
      onSave({ title, answer }, faq?.id);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl transform transition-all">
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-900">{faq ? 'FAQ ပြင်ဆင်ရန်' : 'FAQ အသစ်ထည့်ရန်'}</h3>
              <button type="button" onClick={onClose} aria-label="Close modal">
                 <CloseIcon className="w-6 h-6 text-gray-400 hover:text-gray-600" />
              </button>
            </div>
            <div className="mt-4 space-y-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700">ခေါင်းစဉ်</label>
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="မေးခွန်းခေါင်းစဉ်ထည့်ပါ"
                  required
                />
              </div>
              <div>
                <label htmlFor="answer" className="block text-sm font-medium text-gray-700">အဖြေ</label>
                <textarea
                  id="answer"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  rows={6}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="မေးခွန်း၏အဖြေကိုထည့်ပါ"
                  required
                />
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-6 py-4 flex justify-end space-x-3 rounded-b-lg">
            <button
              type="button"
              className="px-4 py-2 bg-white text-gray-700 border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
              onClick={onClose}
            >
              မလုပ်တော့ပါ
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white border border-transparent rounded-md shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              သိမ်းဆည်းမည်
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FaqFormModal;
