import React from 'react';
import type { FaqItem } from '../types';
import { CloseIcon } from './icons';

interface FaqViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  faq: FaqItem | null;
}

const FaqViewModal: React.FC<FaqViewModalProps> = ({ isOpen, onClose, faq }) => {
  if (!isOpen || !faq) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl transform transition-all">
        <div className="p-6">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-medium text-gray-900">FAQ အသေးစိတ်</h3>
            <button type="button" onClick={onClose} aria-label="Close modal">
              <CloseIcon className="w-6 h-6 text-gray-400 hover:text-gray-600" />
            </button>
          </div>
          <div className="mt-4 space-y-4 prose max-w-none">
            <div className="border-t pt-4">
              <h4 className="font-bold text-gray-800">ခေါင်းစဉ်</h4>
              <p className="text-gray-700 mt-1">{faq.title}</p>
            </div>
            <div className="border-t pt-4">
              <h4 className="font-bold text-gray-800">အဖြေ</h4>
              <p className="text-gray-700 mt-1 whitespace-pre-wrap">{faq.answer}</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 px-6 py-4 flex justify-end rounded-b-lg">
          <button
            type="button"
            className="px-4 py-2 bg-white text-gray-700 border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            onClick={onClose}
          >
            ပိတ်မည်
          </button>
        </div>
      </div>
    </div>
  );
};

export default FaqViewModal;