import React, { useState, useMemo } from 'react';
import FaqFormModal from './FaqFormModal';
import ConfirmationModal from './ConfirmationModal';
import FaqViewModal from './FaqViewModal';
import { SearchIcon, PlusIcon, PencilIcon, TrashIcon, EyeIcon } from './icons';
import type { FaqItem } from '../types';

interface FaqPageProps {
    faqs: FaqItem[];
    isLoading: boolean;
    error: string | null;
    onSave: (faqData: Omit<FaqItem, 'id'>, id?: string) => void;
    onDelete: (faq: FaqItem) => void;
}

const FaqPage: React.FC<FaqPageProps> = ({ faqs, isLoading, error, onSave, onDelete }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [isFormModalOpen, setFormModalOpen] = useState(false);
    const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
    const [isViewModalOpen, setViewModalOpen] = useState(false);
    
    const [selectedFaq, setSelectedFaq] = useState<FaqItem | null>(null);
    const [faqToDelete, setFaqToDelete] = useState<FaqItem | null>(null);
    const [faqToView, setFaqToView] = useState<FaqItem | null>(null);


    const handleOpenFormModal = (faq: FaqItem | null = null) => {
        setSelectedFaq(faq);
        setFormModalOpen(true);
    };

    const handleSave = (faqData: Omit<FaqItem, 'id'>, id?: string) => {
        onSave(faqData, id);
        setFormModalOpen(false);
    };

    const handleOpenConfirmModal = (faq: FaqItem) => {
        setFaqToDelete(faq);
        setConfirmModalOpen(true);
    };

    const handleOpenViewModal = (faq: FaqItem) => {
        setFaqToView(faq);
        setViewModalOpen(true);
    };

    const handleDelete = () => {
        if(faqToDelete) {
            onDelete(faqToDelete);
            setConfirmModalOpen(false);
            setFaqToDelete(null);
        }
    };

    const filteredFaqs = useMemo(() =>
        faqs.filter(faq =>
            faq.title.toLowerCase().includes(searchTerm.toLowerCase())
        ), [faqs, searchTerm]
    );

    return (
        <div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
                     <div className="relative w-full md:w-1/2">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                            type="text"
                            placeholder="ခေါင်းစဉ်ဖြင့် ရှာဖွေပါ..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                        />
                    </div>
                    <button
                        onClick={() => handleOpenFormModal()}
                        className="w-full md:w-auto flex items-center justify-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition"
                    >
                        <PlusIcon className="w-5 h-5 mr-2" />
                        FAQ အသစ်ထည့်ရန်
                    </button>
                </div>

                <div className="overflow-x-auto">
                    {isLoading ? <p className="text-center py-8">ဒေတာများ ရယူနေပါသည်...</p> :
                     error ? <p className="text-center text-red-500 py-8">{error}</p> :
                     filteredFaqs.length > 0 ? (
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ခေါင်းစဉ်</th>
                                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">အဖြေ (အကျဉ်း)</th>
                                    <th scope="col" className="relative px-6 py-3">
                                        <span className="sr-only">လုပ်ဆောင်ချက်များ</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {filteredFaqs.map(faq => (
                                    <tr key={faq.id} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{faq.title}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 max-w-sm truncate">{faq.answer}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                            <button onClick={() => handleOpenViewModal(faq)} className="p-2 text-blue-600 hover:text-blue-900 hover:bg-blue-100 rounded-full transition-colors" aria-label="ကြည့်ရန်">
                                                <EyeIcon className="w-5 h-5" />
                                            </button>
                                            <button onClick={() => handleOpenFormModal(faq)} className="p-2 text-indigo-600 hover:text-indigo-900 hover:bg-indigo-100 rounded-full transition-colors" aria-label="ပြင်ဆင်ရန်">
                                                <PencilIcon className="w-5 h-5" />
                                            </button>
                                            <button onClick={() => handleOpenConfirmModal(faq)} className="p-2 text-red-600 hover:text-red-900 hover:bg-red-100 rounded-full transition-colors" aria-label="ဖျက်ရန်">
                                                <TrashIcon className="w-5 h-5" />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-gray-500 py-8">ရှာဖွေမှုနှင့် ကိုက်ညီသော အချက်အလက်များ မရှိပါ။</p>
                    )}
                </div>
            </div>
            
            <FaqFormModal isOpen={isFormModalOpen} onClose={() => setFormModalOpen(false)} onSave={handleSave} faq={selectedFaq} />
            <ConfirmationModal 
                isOpen={isConfirmModalOpen}
                onClose={() => setConfirmModalOpen(false)}
                onConfirm={handleDelete}
                title="FAQ ဖျက်ရန် အတည်ပြုပါ"
                message={`"${faqToDelete?.title}" ကို အပြီးတိုင် ဖျက်လိုပါသလား။ ဤလုပ်ဆောင်ချက်ကို နောက်ပြန်ပြင်၍မရပါ။`}
            />
            <FaqViewModal
                isOpen={isViewModalOpen}
                onClose={() => setViewModalOpen(false)}
                faq={faqToView}
            />
        </div>
    );
};

export default FaqPage;